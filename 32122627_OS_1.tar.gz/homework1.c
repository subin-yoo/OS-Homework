#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

//Fuction Declaration
void HanoiTowerMove(int num, char from, char by, char to);

int main(void)
{
	int num,i;
	pid_t pids;

	printf("please enter the number of disk:");
	scanf("%d",&num);//Allow user to enter the number
	for(i=0;i<10;i++){
		if(!(pids = fork())){/*If sucess, return child process ID to parent
							   and return 0 to child*/
		printf("Child id : %d\n",getpid());//Get the Child process ID	
		HanoiTowerMove(num,'A','B','C');//Child process executes HanoiTowerMove
		return 0; //Terminate the child process
		}//Child process
	else//Parent Process
		printf("parent id: %d\n",getpid());//Get the Parent process ID
	}//Create 10 child processes	
		
return 0;

}//main

void HanoiTowerMove(int num, char from, char by, char to)
{
	if(num==1)
	{
		printf("disk1 moves from %c to %c \n",from, to);
	}//If there is one disk, move it from A to C
	else
	{
		HanoiTowerMove(num-1,from,to,by);//Move n-1 disks from A to B
		printf("disk%d moves from %c to %c \n",num,from,to);//Move the bottom disk from A to C
		HanoiTowerMove(num-1,by,from,to);//Move n-1 disks from B to C
	}//Move n-1 disks from A to C
}//n disks are moved from A to C through B	

